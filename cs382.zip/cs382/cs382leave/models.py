from django.db import models

# Create your models here.
# class Application(models.Model):
#     from_prof = models.CharField(max_length=122)
#     text_area = models.CharField(max_length=500)
    # document = models.FileField()
    # uploaded_at = models.DateTimeField(auto_now_add=True)
