from django.apps import AppConfig


class Cs382LeaveConfig(AppConfig):
    name = 'cs382leave'
